package br.ufg.inf.mestrado.guilherme;
// CoreDX DDL Generated code.  Do not modify - modifications may be overwritten.


public class SinalVitalTypeSeq {
  
  public SinalVitalType[] value = null;
  public SinalVitalTypeSeq() { };
  public SinalVitalTypeSeq(SinalVitalType[] __v) { value = __v; }
}; // SinalVitalTypeSeq
